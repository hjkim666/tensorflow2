from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

# Import data
from tensorflow.examples.tutorials.mnist import input_data

import tensorflow as tf

flags = tf.app.flags
FLAGS = flags.FLAGS
flags.DEFINE_string('data_dir', '/tmp/data/', 'Directory for storing data')

mnist = input_data.read_data_sets(FLAGS.data_dir, one_hot=True)

sess = tf.InteractiveSession()

# Create the model
X = tf.placeholder(tf.float32, [None, 784])
W1 = tf.get_variable("W1", shape=[784, 256]
                     , initializer=tf.contrib.layers.xavier_initializer(784, 256))
W2 = tf.get_variable("W2", shape=[256, 256]
                     , initializer=tf.contrib.layers.xavier_initializer(256, 256))
W3 = tf.get_variable("W2", shape=[256, 256]
                     , initializer=tf.contrib.layers.xavier_initializer(256, 256))
W4 = tf.get_variable("W3", shape=[256, 10]
                     , initializer=tf.contrib.layers.xavier_initializer(256, 10))

b1 = tf.Variable(tf.zeros([256]))
b2 = tf.Variable(tf.zeros([256]))
b3 = tf.Variable(tf.zeros([256]))
b4 = tf.Variable(tf.zeros([10]))

dropout_rate = tf.placeholder("float")
_L1 = tf.nn.relu(tf.add(tf.matmul(x, W1), b1))   
L1=tf.nn.dropout(_L1,dropout_rate)
_L2 = tf.nn.relu(tf.add(tf.matmul(L1, W2), b2))   
L2=tf.nn.dropout(_L2,dropout_rate)
_L3 = tf.nn.relu(tf.add(tf.matmul(L2, W3), b3))   
L3=tf.nn.dropout(_L3,dropout_rate)
_L4 = tf.nn.relu(tf.add(tf.matmul(L3, W4), b4))  
L4=tf.nn.dropout(_L4,dropout_rate)
hypothesis = tf.matmul(L4, W4) + b4

# Define loss and optimizer
Y = tf.placeholder(tf.float32, [None, 10])
cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(hypothesis, Y))
train_step = tf.train.AdamOptimizer(learning_rate=0.001).minimize(cost)

# Train
tf.initialize_all_variables().run()
for i in range(1000):
  batch_xs, batch_ys = mnist.train.next_batch(100)
  train_step.run({X: batch_xs, Y: batch_ys, dropout_rate:0.7})

# Test trained model
correct_prediction = tf.equal(tf.argmax(hypothesis, 1), tf.argmax(Y, 1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
print(accuracy.eval({X: mnist.test.images, Y: mnist.test.labels, dropout_rate:1}))