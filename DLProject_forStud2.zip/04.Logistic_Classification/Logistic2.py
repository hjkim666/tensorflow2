import tensorflow as tf
import numpy as np

xy = np.genfromtxt('mycars.csv',delimiter=','
                   , skip_header=1
                   , unpack=True, dtype='float32')

x_data = xy[0:-1]
y_data = xy[-1]
#tmp = np.zeros([len(x_data),1])
#x_data = np.append(tmp ,x_data, 1)
#a = np.zeros([len(x_data), 1])
#print a

print x_data
print y_data
x_data = np.transpose(x_data)
#y_data = np.transpose(y_data)
tmp = np.ones([len(x_data),1])
x_data = np.append(tmp ,x_data, 1)

#print x_data
#print y_data

print x_data.shape
print y_data.shape

X = tf.placeholder(tf.float32)
Y = tf.placeholder(tf.float32)

W = tf.Variable(tf.random_uniform([8,1], -1.0, 1.0))
#b = tf.Variable(tf.random_uniform([7], -1.0, 1.0))

h = tf.matmul(X, W)
hypothesis = tf.div(1., 1. + tf.exp(-h))

cost = -tf.reduce_mean(Y * tf.log(hypothesis) + (1 - Y) * tf.log(1 - hypothesis))

a = tf.Variable(0.00001)  # learning rate, alpha
optimizer = tf.train.GradientDescentOptimizer(a)
train = optimizer.minimize(cost)  # goal is minimize cost

init = tf.initialize_all_variables()

sess = tf.Session()
sess.run(init)

for step in xrange(20001):
    sess.run(train, feed_dict={X: x_data, Y: y_data})
    if step % 20 == 0:
        print step, sess.run(cost, feed_dict={X: x_data, Y: y_data}), sess.run(W)

print '-----------------------------------------'
print sess.run(hypothesis, feed_dict={X: [[16.9],[5.917],[4.36],[350],[8],[155],[14.9]]}) > 0.5
#print sess.run(hypothesis, feed_dict={X: [[1], [5], [5]]}) > 0.5
#print sess.run(hypothesis, feed_dict={X: [[1, 1], [4, 0], [2, 10]]}) > 0.5
