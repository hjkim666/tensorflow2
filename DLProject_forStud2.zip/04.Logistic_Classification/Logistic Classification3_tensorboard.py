import tensorflow as tf
import numpy as np

xy = np.genfromtxt('binary.csv',delimiter=','
                   , skip_header=1
                   , unpack=True, dtype='float32')
x_data = np.transpose(xy[0:-1])
y_data = np.transpose(xy[-1])

print x_data.shape 
#print y_data
#print x_data[:,1]

x_data[:,1] =(x_data[:,1] - x_data[:,1].mean())/x_data[:,1].std()
X = tf.placeholder(tf.float32)
Y = tf.placeholder(tf.float32)

with tf.name_scope("Wlayer") as scope:
    W = tf.Variable(tf.random_uniform([4, 1], -1.0, 1.0))

h = tf.matmul(X, W)
hypothesis = tf.div(1., 1. + tf.exp(-h))

with tf.name_scope("cost") as scope:
    cost = -tf.reduce_mean(Y * tf.log(hypothesis) + (1 - Y) * tf.log(1 - hypothesis))
    cost_sum = tf.scalar_summary("cost", cost) 
    
with tf.name_scope("train") as scope:    
    a = tf.Variable(0.01)  # learning rate, alpha
    optimizer = tf.train.GradientDescentOptimizer(a)
    train = optimizer.minimize(cost)  # goal is minimize cost

init = tf.initialize_all_variables()

with tf.Session() as sess: 
    merged = tf.merge_all_summaries()
    writer = tf.train.SummaryWriter("/tmp/mylog",  sess.graph)
    sess.run(init)
    
    for step in xrange(2001):
        sess.run(train, feed_dict={X: x_data, Y: y_data})
    
        if step % 20 == 0:
            print step, sess.run(cost, feed_dict={X: x_data, Y: y_data}), sess.run(W)
            summary, _ = sess.run( [merged, train], feed_dict={X:x_data, Y:y_data})
            writer.add_summary(summary, step)

