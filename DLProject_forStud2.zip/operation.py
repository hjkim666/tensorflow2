import tensorflow as tf

a = tf.constant(2)
b = tf.constant(3)

c = a + b
print c

sess = tf.Session()
print sess.run(c)