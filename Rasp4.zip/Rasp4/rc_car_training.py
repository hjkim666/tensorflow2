import tensorflow as tf 
import numpy as np 
import os ,time
from tensorflow.core.protobuf.config_pb2 import GPUOptions
from tensorflow.contrib.learn.python.learn import summary_writer_cache
from datetime import datetime
tf.reset_default_graph()

now = datetime.now()
now_str = now.strftime("%Y%m%d-%H%M%S.%f")
cwd = os.getcwd()
loadpath = cwd + "/data/myData.npz"
l = np.load(loadpath)
print (l.files)

imgsize = [64,64]
use_gray =1 
data_name = "myData"

# PARSE LOADED DATA #####################
trainimg = l['trainimg']
trainlabel = l['trainlabel']
testimg = l['testimg']
testlabel = l['testlabel']
imgsize = l['imgsize']
use_gray = l['use_gray']
ntrain = trainimg.shape[0]
nclass = trainlabel.shape[1]
dim    = trainimg.shape[1]
tf.set_random_seed(0)
n_input  = dim
n_output = nclass

with tf.variable_scope('base') as scope:
    if use_gray:
        weights  = {
            'wc1': tf.Variable(tf.random_normal([5, 5, 1, 128], stddev=0.1),name='wc1'),
            'wc2': tf.Variable(tf.random_normal([5, 5, 128, 128], stddev=0.1),name='wc2'),
            'wd1': tf.Variable(tf.random_normal(
                    [(int)(imgsize[0]/4*imgsize[1]/4)*128, 128], stddev=0.1),name='wd1'),
            'wd2': tf.Variable(tf.random_normal([128, n_output], stddev=0.1),name='wd2')
        }
    else:
        weights  = {
            'wc1': tf.Variable(tf.random_normal([5, 5, 3, 128], stddev=0.1),name='wc1'),
            'wc2': tf.Variable(tf.random_normal([5, 5, 128, 128], stddev=0.1),name='wc2'),
            'wd1': tf.Variable(tf.random_normal(
                    [(int)(imgsize[0]/4*imgsize[1]/4)*128, 128], stddev=0.1),name='wd1'),
            'wd2': tf.Variable(tf.random_normal([128, n_output], stddev=0.1),name='wd2')
        }
    biases   = {
        'bc1': tf.Variable(tf.random_normal([128], stddev=0.1),name='bc1'),
        'bc2': tf.Variable(tf.random_normal([128], stddev=0.1),name='bc2'),
        'bd1': tf.Variable(tf.random_normal([128], stddev=0.1),name='bd1'),
        'bd2': tf.Variable(tf.random_normal([n_output], stddev=0.1),name='bd2')
    }


def conv_basic(_input, _w, _b, _keepratio, _use_gray):
    
    with tf.name_scope('conv_basic'):
        # INPUT
        if _use_gray:
            _input_r = tf.reshape(_input, shape=[-1, imgsize[0], imgsize[1], 1])
        else:
            _input_r = tf.reshape(_input, shape=[-1, imgsize[0], imgsize[1], 3])
        # CONVOLUTION LAYER 1
        #with tf.name_scope('conv_layer1'):
        _conv1 = tf.nn.relu(tf.nn.bias_add(tf.nn.conv2d(_input_r
            , _w['wc1'], strides=[1, 1, 1, 1], padding='SAME',name=scope.name), _b['bc1']), name='_conv1')
    
    #     b=tf.nn.conv2d(_input_r, _w['wc1'], strides=[1, 1, 1, 1], padding='SAME', name='b')
    #     a = tf.nn.bias_add(b, _b['bc1'], name='a')
    #     _conv1 = tf.nn.relu(a, name='_conv1')
        print _conv1.name
        _pool1 = tf.nn.max_pool(_conv1, ksize=[1, 2, 2, 1]
            , strides=[1, 2, 2, 1], padding='SAME', name='_pool1')
        print _pool1.name
        _pool_dr1 = tf.nn.dropout(_pool1, _keepratio, name='_pool_dr1')
        # CONVOLUTION LAYER 2
        _conv2 = tf.nn.relu(tf.nn.bias_add(tf.nn.conv2d(_pool_dr1
            , _w['wc2'], strides=[1, 1, 1, 1], padding='SAME'), _b['bc2']), name='_conv2')
        _pool2 = tf.nn.max_pool(_conv2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME',name='_pool2')
        _pool_dr2 = tf.nn.dropout(_pool2, _keepratio, name='_pool_dr2')
        # VECTORIZE
        _dense1 = tf.reshape(_pool_dr2, [-1, _w['wd1'].get_shape().as_list()[0]])
        # FULLY CONNECTED LAYER 1
        _fc1 = tf.nn.relu(tf.add(tf.matmul(_dense1, _w['wd1']), _b['bd1']), name='_fc1')
        _fc_dr1 = tf.nn.dropout(_fc1, _keepratio, name='_fc_dr1')
        # FULLY CONNECTED LAYER 2
        _out = tf.add(tf.matmul(_fc_dr1, _w['wd2']), _b['bd2'], name='_out')
        # RETURN
        out = {
            'input_r': _input_r, 'conv1': _conv1, 'pool1': _pool1
            , 'pool1_dr1': _pool_dr1, 'conv2': _conv2, 'pool2': _pool2
            , 'pool_dr2': _pool_dr2, 'dense1': _dense1, 'fc1': _fc1
            , 'fc_dr1': _fc_dr1, 'out': _out
        }
        return out
print ("NETWORK READY")


#DEFINE FUNCTIONS
# tf Graph input
x = tf.placeholder(tf.float32, [None, n_input], name='x')
y = tf.placeholder(tf.float32, [None, n_output], name='y')
keepratio = tf.placeholder(tf.float32, name='keepratio')

# Launch the graph
#with tf.Graph().as_default() as g:
# Functions! 
_pred = conv_basic(x, weights, biases, keepratio, use_gray)['out']
cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(_pred, y), name='cross_entropy_with_logits')
WEIGHT_DECAY_FACTOR = 0.0001
l2_loss = tf.add_n([tf.nn.l2_loss(v) 
            for v in tf.trainable_variables()], name='l2_loss')
cost = cost + WEIGHT_DECAY_FACTOR*l2_loss
optm = tf.train.AdamOptimizer(learning_rate=0.001).minimize(cost)
_corr = tf.equal(tf.argmax(_pred,1), tf.argmax(y,1)) # Count corrects
accr = tf.reduce_mean(tf.cast(_corr, tf.float32)) # Accuracy
init = tf.initialize_all_variables()
print ("FUNCTIONS READY")
print (now_str)

#Optimize ###########
# Parameters
training_epochs = 400
batch_size      = 100
display_step    = 40


#with tf.Session() as sess:
sess = tf.Session(config=tf.ConfigProto(gpu_options=tf.GPUOptions(allow_growth=True)))
sess.run(init)
#summary_writer = tf.train.SummaryWriter("./tmp/rc_model", sess.graph)
summary_writer = tf.summary.FileWriter("./tmp/rc_model", sess.graph)

#saver.restore0(sess,'rc_model.ckpt')
saver = tf.train.Saver(max_to_keep=11)
#saver.restore(sess, 'rc_model')

# Training cycle
for epoch in range(training_epochs):
    avg_cost = 0.
    num_batch = int(ntrain/batch_size)+1
    # Loop over all batches
    for i in range(num_batch): 
        randidx = np.random.randint(ntrain, size=batch_size)
        batch_xs = trainimg[randidx, :]
        batch_ys = trainlabel[randidx, :]                
        # Fit training using batch data
        sess.run(optm, feed_dict={x: batch_xs, y: batch_ys
                                  , keepratio:0.7})
        # Compute average loss
        avg_cost += sess.run(cost, feed_dict={x: batch_xs, y: batch_ys
                                , keepratio:1.})/num_batch
        #saver.save(sess,'rc_model.ckpt')                        
    # Display logs per epoch step
    if epoch % display_step == 0 or epoch == training_epochs-1:
        print ("Epoch: %03d/%03d cost: %.9f" % 
               (epoch, training_epochs, avg_cost))
        train_acc = sess.run(accr, feed_dict={x: batch_xs
                                , y: batch_ys, keepratio:1.})
        print (" Training accuracy: %.3f" % (train_acc))
        test_acc = sess.run(accr, feed_dict={x: testimg
                                , y: testlabel, keepratio:1.})
        print (" Test accuracy: %.3f" % (test_acc))
        saver.save(sess,'rc_model',global_step=i)
print ("Optimization Finished!")

sess.close()
print ("Session closed.")
print (now_str)
