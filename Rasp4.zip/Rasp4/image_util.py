import numpy as np 
import os
import scipy.misc 

imgsize = [64,64]
use_gray =1 

def rgb2gray(rgb):
    if len(rgb.shape) is 3:
        return np.dot(rgb[...,:3], [0.299, 0.587, 0.114])
    else:
        # print ("Current Image if GRAY!")
        return rgb
    
def downsize(cimg):
    if use_gray:
        grayimg  = rgb2gray(cimg)
    else:
        grayimg  = cimg
        # Reshape
    graysmall = scipy.misc.imresize(grayimg, [imgsize[0], imgsize[1]])/255.    
    return graysmall        
