import tensorflow as tf 
import numpy as np 
import os 
tf.reset_default_graph()

imgsize = [64,64]
use_gray =1 

n_input  = imgsize[0]*imgsize[1]
#n_output = 4
n_output = 5  # lable 5 : 0,1,2,3,4 

x = tf.placeholder(tf.float32, [None, n_input], name='x')
y = tf.placeholder(tf.float32, [None, n_output], name='y')
keepratio = tf.placeholder(tf.float32, name='keepratio')


with tf.variable_scope('base') as scope:
    if use_gray:
        weights  = {
            'wc1': tf.Variable(tf.random_normal([5, 5, 1, 128], stddev=0.1),name='wc1'),
            'wc2': tf.Variable(tf.random_normal([5, 5, 128, 128], stddev=0.1),name='wc2'),
            'wd1': tf.Variable(tf.random_normal(
                    [(int)(imgsize[0]/4*imgsize[1]/4)*128, 128], stddev=0.1),name='wd1'),
            'wd2': tf.Variable(tf.random_normal([128, n_output], stddev=0.1),name='wd2')
        }
    else:
        weights  = {
            'wc1': tf.Variable(tf.random_normal([5, 5, 3, 128], stddev=0.1),name='wc1'),
            'wc2': tf.Variable(tf.random_normal([5, 5, 128, 128], stddev=0.1),name='wc2'),
            'wd1': tf.Variable(tf.random_normal(
                    [(int)(imgsize[0]/4*imgsize[1]/4)*128, 128], stddev=0.1),name='wd1'),
            'wd2': tf.Variable(tf.random_normal([128, n_output], stddev=0.1),name='wd2')
        }
    biases   = {
        'bc1': tf.Variable(tf.random_normal([128], stddev=0.1),name='bc1'),
        'bc2': tf.Variable(tf.random_normal([128], stddev=0.1),name='bc2'),
        'bd1': tf.Variable(tf.random_normal([128], stddev=0.1),name='bd1'),
        'bd2': tf.Variable(tf.random_normal([n_output], stddev=0.1),name='bd2')
    }


sess = tf.Session(config=tf.ConfigProto(gpu_options=tf.GPUOptions(allow_growth=True)))
sess.run(tf.global_variables_initializer())
saver = tf.train.import_meta_graph('./rc_model-1.meta')
saver.restore(sess,'./rc_model-1')

def conv_basic(_input, _w, _b, _keepratio, _use_gray):
    
    with tf.name_scope('conv_basic'):
        # INPUT
        if _use_gray:
            _input_r = tf.reshape(_input, shape=[-1, imgsize[0], imgsize[1], 1])
        else:
            _input_r = tf.reshape(_input, shape=[-1, imgsize[0], imgsize[1], 3])
        # CONVOLUTION LAYER 1
        _conv1 = tf.nn.relu(tf.nn.bias_add(tf.nn.conv2d(_input_r
            , _w['wc1'], strides=[1, 1, 1, 1], padding='SAME',name=scope.name), _b['bc1']), name='_conv1')
    
        #print _conv1.name
        _pool1 = tf.nn.max_pool(_conv1, ksize=[1, 2, 2, 1]
            , strides=[1, 2, 2, 1], padding='SAME', name='_pool1')
        #print _pool1.name
        _pool_dr1 = tf.nn.dropout(_pool1, _keepratio, name='_pool_dr1')
        # CONVOLUTION LAYER 2
        _conv2 = tf.nn.relu(tf.nn.bias_add(tf.nn.conv2d(_pool_dr1
            , _w['wc2'], strides=[1, 1, 1, 1], padding='SAME'), _b['bc2']), name='_conv2')
        _pool2 = tf.nn.max_pool(_conv2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME',name='_pool2')
        _pool_dr2 = tf.nn.dropout(_pool2, _keepratio, name='_pool_dr2')
        #print _pool_dr2
        # VECTORIZE
        _dense1 = tf.reshape(_pool_dr2, [-1, _w['wd1'].get_shape().as_list()[0]])
        # FULLY CONNECTED LAYER 1
        _fc1 = tf.nn.relu(tf.add(tf.matmul(_dense1, _w['wd1']), _b['bd1']), name='_fc1')
        _fc_dr1 = tf.nn.dropout(_fc1, _keepratio, name='_fc_dr1')
        #print _fc_dr1
        # FULLY CONNECTED LAYER 2
        _out = tf.add(tf.matmul(_fc_dr1, _w['wd2']), _b['bd2'], name='_out')
        # RETURN
        out = {
            'input_r': _input_r, 'conv1': _conv1, 'pool1': _pool1
            , 'pool1_dr1': _pool_dr1, 'conv2': _conv2, 'pool2': _pool2
            , 'pool_dr2': _pool_dr2, 'dense1': _dense1, 'fc1': _fc1
            , 'fc_dr1': _fc_dr1, 'out': _out
        }
        return out
print ("NEURAL NETWORK READY")



#DEFINE FUNCTIONS

def prediction(stream_image):
    
    _pred = conv_basic(x, weights, biases, keepratio, use_gray)['out']
    
    test = sess.run(_pred, feed_dict={x: stream_image.reshape(1,4096),keepratio:1.})
    
    result = sess.run(tf.argmax(test,1))
 
    return result

if __name__=="__main__":
    prediction()
    
    #filename_queue = tf.train.string_input_producer(['./test/forward_test.jpg']) #  list of files to read
    #reader = tf.WholeFileReader()
    #key, value = reader.read(filename_queue)

    #my_img = tf.image.decode_png(value)
    #prediction(my_img)

