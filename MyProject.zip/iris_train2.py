import tensorflow as tf
import numpy as np 
import pandas as pd

xy = np.genfromtxt('iris_training.csv',delimiter=',', skip_header=1, unpack=True, dtype='float32')
x_data = xy[0:-1]
x_data = np.transpose(xy[0:-1])
y_data = np.array(pd.get_dummies(xy[-1]))
 
print x_data
print y_data

X = tf.placeholder(tf.float32, name='x-input')
Y = tf.placeholder(tf.float32, name='y-input')

w1 = tf.Variable(tf.random_uniform([4, 20], -1.0, 1.0), name='weight1')
w2 = tf.Variable(tf.random_uniform([20, 10], -1.0, 1.0), name='weight2')
w3 = tf.Variable(tf.random_uniform([10, 3], -1.0, 1.0), name='weight3')

b1 = tf.Variable(tf.zeros([20]), name="Bias1")
b2 = tf.Variable(tf.zeros([10]), name="Bias2")
b3 = tf.Variable(tf.zeros([3]), name="Bias3")

L2 = tf.nn.relu(tf.matmul(X, w1) + b1)
L3 = tf.nn.relu(tf.matmul(L2, w2) + b2)
hypothesis = tf.sigmoid(tf.matmul(L3, w3) + b3)

with tf.name_scope('cost') as scope:
    cost = -tf.reduce_mean(Y * tf.log(hypothesis) + (1-Y) * tf.log(1 - hypothesis))
    cost_summ = tf.scalar_summary("cost", cost)

with tf.name_scope('train') as scope:
    a = tf.Variable(0.01)
    optimizer = tf.train.GradientDescentOptimizer(a)
    train = optimizer.minimize(cost)

init = tf.initialize_all_variables()

with tf.Session() as sess:
    sess.run(init)

    merged = tf.merge_all_summaries()
    writer = tf.train.SummaryWriter("/tmp/iris_log", sess.graph)

    for step in xrange(10000):
        sess.run(train, feed_dict={X: x_data, Y: y_data})
        if step % 200 == 0:
            summary = sess.run(merged, feed_dict={X: x_data, Y: y_data})
            writer.add_summary(summary, step)
            print step, sess.run(cost, feed_dict={X: x_data, Y: y_data}), sess.run(w1), sess.run(w2)

    correct_prediction = tf.equal(tf.arg_max(hypothesis,1), tf.arg_max(y_data,1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction,'float'))
    print sess.run([hypothesis, tf.arg_max(hypothesis,1), correct_prediction],feed_dict={X:x_data, Y:y_data})
    print "train accuracy", accuracy.eval(feed_dict={X:x_data, Y:y_data})


######################################################################
## test 1 row  -> setosa,versicolor,virginica /n 5.9,3.0,4.2,1.5,1
######################################################################
    test1 = sess.run(hypothesis, feed_dict={X: [[5.9,3.0,4.2,1.5]]})
    print "test1 :", test1, sess.run(tf.arg_max(test1, 1))
   
    xyt = np.genfromtxt('iris_test.csv',delimiter=',', skip_header=1, unpack=True, dtype='float32')
    x_datat = np.transpose(xyt[0:-1])
    y_datat = np.array(pd.get_dummies(xyt[-1]))

    correct_prediction = tf.equal(tf.arg_max(hypothesis,1), tf.arg_max(y_datat,1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction,'float'))
    print sess.run([hypothesis, tf.arg_max(hypothesis,1), correct_prediction],feed_dict={X:x_datat, Y:y_datat})
    print "test accuracy", accuracy.eval(feed_dict={X:x_datat, Y:y_datat})    

