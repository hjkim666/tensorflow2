import tensorflow as tf
import numpy as np 
import pandas as pd

xy = np.genfromtxt('iris_training.csv',delimiter=',', skip_header=1, unpack=True, dtype='float32')
x_data = xy[0:-1]
y_data_tmp = xy[-1]
x_data = np.transpose(xy[0:-1])
y_data = pd.get_dummies(y_data_tmp)
#y_data = np.reshape(xy[-1], (len(x_data), 1))
y_data = np.array(y_data)

print(x_data)
print(y_data)

X = tf.placeholder(tf.float32, name='x-input')
Y = tf.placeholder(tf.float32, name='y-input')

W = tf.Variable(tf.random_uniform([4, 3], -1, 1))
b = tf.Variable(tf.random_uniform([3], -1, 1))

hypothesis = tf.matmul(X, W) + b

cost = tf.reduce_mean(tf.square(hypothesis - Y))

a = tf.Variable(0.001)  # learning rate, alpha, form 0.1
optimizer = tf.train.GradientDescentOptimizer(a)
train = optimizer.minimize(cost)  # goal is minimize cost

init = tf.initialize_all_variables()

sess = tf.Session()
sess.run(init)

for step in xrange(20001):
     sess.run(train, feed_dict={X: x_data, Y: y_data})
     if step % 20 == 0:
        print step, sess.run(cost, feed_dict={X:x_data, Y:y_data}), sess.run(W)


correct_prediction = tf.equal(tf.arg_max(tf.floor(hypothesis+0.5),1), tf.argmax(y_data,1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))
print sess.run([hypothesis, tf.arg_max(tf.floor(hypothesis+0.5),1), correct_prediction], feed_dict={X: x_data, Y: y_data})
print "train accuracy", accuracy.eval(session=sess,feed_dict={X: x_data, Y: y_data})

######################################################################
## test 1 row
######################################################################
test1 = sess.run(hypothesis, feed_dict={X: [[5.9,3.0,4.2,1.5]]})
print "test1 :", test1, sess.run(tf.arg_max(test1, 1))


#######################################################################    
## Evaluation
#######################################################################
xyt = np.genfromtxt('iris_test.csv',delimiter=',', skip_header=1, unpack=True, dtype='float32')

x_datat = np.transpose(xyt[0:-1])
y_datat = np.array(pd.get_dummies(xyt[-1]))

correct_prediction = tf.equal(tf.arg_max(tf.floor(hypothesis+0.5),1), tf.argmax(y_datat,1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))
print sess.run([hypothesis, tf.arg_max(tf.floor(hypothesis+0.5),1), correct_prediction], feed_dict={X: x_datat, Y: y_datat})
print "test accuracy", accuracy.eval(session=sess,feed_dict={X: x_datat, Y: y_datat})


