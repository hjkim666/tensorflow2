import tensorflow as tf
import numpy as np
import pandas as pd

xy = np.genfromtxt('iris_training.csv',delimiter=',',skip_header=1,unpack=True,dtype='float32')

x_data = np.transpose(xy[0:-1])
x_data[:,1] = (x_data[:,1] - x_data[:,1].mean()) / x_data[:,1].std()
print(np.shape(x_data))
y_data = pd.get_dummies(xy[-1])
y_data = np.array(y_data)

x = tf.placeholder(tf.float32)
y = tf.placeholder(tf.float32)
w = [tf.Variable(tf.random_uniform([4,200], -1.0, 1.0)),
    tf.Variable(tf.random_uniform([200,100], -1.0, 1.0)),
    tf.Variable(tf.random_uniform([100,50], -1.0, 1.0)),
    tf.Variable(tf.random_uniform([50,25], -1.0, 1.0)),
    tf.Variable(tf.random_uniform([25,12], -1.0, 1.0)),
    tf.Variable(tf.random_uniform([12,6], -1.0, 1.0)),
    tf.Variable(tf.random_uniform([6,3], -1.0, 1.0))]

b = [tf.Variable(tf.zeros([200]), name="Bias1"),
    tf.Variable(tf.zeros([100]), name="Bias2"),
    tf.Variable(tf.zeros([50]), name="Bias3"),
    tf.Variable(tf.zeros([25]), name="Bias4"),
    tf.Variable(tf.zeros([12]), name="Bias5"),
    tf.Variable(tf.zeros([6]), name="Bias6"),
    tf.Variable(tf.zeros([3]), name="Bias7")]
L = [tf.sigmoid(tf.matmul(x,w[0])+b[0])]

for i in range(0,5):
    L.append(tf.sigmoid(tf.matmul(L[-1],w[i+1])+b[i+1]))

hypothesis = tf.sigmoid(tf.matmul(L[-1],w[-1])+b[-1])

#cost
cost = -tf.reduce_mean(y*tf.log(hypothesis) + (1-y)*tf.log(1-hypothesis))

a = tf.Variable(0.5)
optimizer = tf.train.GradientDescentOptimizer(a)
train = optimizer.minimize(cost)

init = tf.initialize_all_variables()

with tf.Session() as sess:
    sess.run(init)

    for step in xrange(20000):
        sess.run(train, feed_dict={x:x_data, y:y_data})
        if step%1000==0:
            print(step, sess.run(cost, feed_dict={x:x_data, y:y_data}))

    correct_prediction = tf.equal(tf.floor(hypothesis+0.5),y)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction,"float"))
    print(sess.run([hypothesis, tf.floor(hypothesis+0.5), correct_prediction, accuracy], feed_dict={x:x_data, y:y_data}))
    print("Accuracy:", accuracy.eval({x:x_data, y:y_data}))
